#ifndef __USUAL_H_
#define __USUAL_H_

void SetOrRead(unsigned char times,unsigned char keynum);

#endif